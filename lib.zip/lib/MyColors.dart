import 'package:flutter/material.dart';

var darkTheme = ThemeData(
  textTheme: TextTheme(
    headline1: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 28,
    ),
  ),
);
var lightTheme = ThemeData();

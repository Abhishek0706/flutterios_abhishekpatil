class FeeListModel {
  String title;
  bool isCheck;

  FeeListModel(this.title, {this.isCheck = false});

  static List<FeeListModel> getFees() {
    return <FeeListModel>[
      FeeListModel("150 - 300 rs"),
      FeeListModel("300 - 750 rs"),
      FeeListModel("750 - 1000 rs"),
      FeeListModel("1000 - 1500+ rs"),
    ];
  }
}

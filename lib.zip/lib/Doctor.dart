class Doctor {
  String name;
  int age;
  String speciality;
  String rating;
  String clinic;
  Doctor(this.name, this.age, this.speciality, this.rating, this.clinic);
}

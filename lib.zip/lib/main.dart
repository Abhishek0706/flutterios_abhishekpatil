import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutterios_abhishekpatil/DoctorList.dart';
import 'package:flutterios_abhishekpatil/Models/DayListModel.dart';
import 'package:flutterios_abhishekpatil/Models/FeeListModel.dart';
import 'package:flutterios_abhishekpatil/Models/GenderListModel.dart';
import 'package:flutterios_abhishekpatil/Models/SpecialityListModel.dart';

import 'dart:async';

import 'package:google_maps_flutter/google_maps_flutter.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool light = true;
  bool switchState = false;
  late GoogleMapController _controller;

  static final CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(22.7419562, 75.88835222),
    zoom: 14.4746,
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Upcloud Technology',
      debugShowCheckedModeBanner: false,
      home: myHome(context),
      theme: light ? ThemeData.light() : ThemeData.dark(),
    );
  }

  Widget myHome(BuildContext context) {
    return Scaffold(
      endDrawer: myDrawer(context),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: IconThemeData(
          color: Colors.black,
        ),
        actions: [
          Switch(
            value: switchState,
            onChanged: (value) {
              setState(() {
                light = !light;
                switchState = !switchState;
                changeMapMode();
              });
            },
          ),
          Builder(
            builder: (context) => IconButton(
              icon: Icon(
                Icons.filter_list_sharp,
                size: 40,
              ),
              onPressed: () => Scaffold.of(context).openEndDrawer(),
              tooltip: MaterialLocalizations.of(context).openAppDrawerTooltip,
            ),
          ),
        ],
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: <Widget>[
          mapScreen(context),
          DoctorList(),
        ],
      ),
    );
  }

  Widget mapScreen(BuildContext context) {
    return new Scaffold(
      body: GoogleMap(
        mapType: MapType.normal,
        initialCameraPosition: _kGooglePlex,
        onMapCreated: (GoogleMapController controller) {
          _controller = controller;
          changeMapMode();
          setState(() {});
        },
        zoomControlsEnabled: false,
        myLocationButtonEnabled: true,
      ),
    );
  }

  changeMapMode() {
    String temp = light ? "assets/lightMap.json" : "assets/darkMap.json";

    getJsonFile(temp).then(setMapStyle);
  }

  Future<String> getJsonFile(String path) async {
    return await rootBundle.loadString(path);
  }

  void setMapStyle(String mapStyle) {
    _controller.setMapStyle(mapStyle);
  }
}

Drawer myDrawer(BuildContext context) {
  var dayList = DayListModel.getDays();
  var feeList = FeeListModel.getFees();
  var specialityList = SpecialityListModel.getSpecialities();
  var genderList = GenderListModel.getGenders();

  return Drawer(
    child: ListView(
      padding: EdgeInsets.zero,
      children: [
        Container(
          height: 140,
          child: DrawerHeader(
            child: Row(
              children: [
                Icon(
                  Icons.filter_list_sharp,
                  color: Colors.black,
                  size: 40,
                ),
                SizedBox(
                  width: 10,
                ),
                Text(
                  "Filters",
                  style: TextStyle(fontSize: 30),
                ),
              ],
            ),
          ),
        ),
        ExpansionTile(
          title: Text("Availability"),
          children: [
            for (var i in dayList)
              CheckboxListTile(
                value: i.isCheck,
                onChanged: null,
                title: Text(i.title),
              )
          ],
        ),
        ExpansionTile(
          title: Text("Fees"),
          children: [
            for (var i in feeList)
              CheckboxListTile(
                value: i.isCheck,
                onChanged: null,
                title: Text(i.title),
              )
          ],
        ),
        ExpansionTile(
          title: Text("Speciality"),
          children: [
            for (var i in specialityList)
              CheckboxListTile(
                value: i.isCheck,
                onChanged: null,
                title: Text(i.title),
              )
          ],
        ),
        ExpansionTile(
          title: Text("Gender"),
          children: [
            for (var i in genderList)
              CheckboxListTile(
                value: i.isCheck,
                onChanged: null,
                title: Text(i.title),
              )
          ],
        ),
        Center(
          child: TextButton(
            onPressed: null,
            child: Text(
              'Clear Filter',
              style: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            style: ButtonStyle(
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18),
                  side: BorderSide(color: Colors.red),
                ),
              ),
            ),
          ),
        )
      ],
    ),
  );
}

import 'package:flutterios_abhishekpatil/Doctor.dart';

List<Doctor> doctorDetail = [
  new Doctor("Abhishek", 22, "ear", "4.7", "Apna Clinic"),
  new Doctor("Sanjeet", 22, "ear", "4.5", "Uska Clinic"),
  new Doctor("Naman", 22, "heart", "2.3", "Kiska Clinic"),
  new Doctor("Nishant", 22, "heart", "3.5", "Iska Clinic"),
  new Doctor("Devjeet", 22, "bone", "5.3", "Konsa Clinic"),
  new Doctor("Samyak", 22, "bone", "5.2", "Accha Clinic"),
  new Doctor("Devendra", 22, "nose", "4.2", "Bekar Clinic"),
  new Doctor("Harsh", 22, "nose", "1.7", "Bada Clinic"),
];

import 'package:flutter/material.dart';
import 'package:flutterios_abhishekpatil/DoctorCard.dart';
import 'package:flutterios_abhishekpatil/DoctorDetail.dart';

class DoctorList extends StatefulWidget {
  DoctorList({Key? key}) : super(key: key);

  @override
  _DoctorListState createState() => _DoctorListState();
}

class _DoctorListState extends State<DoctorList> {
  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        height: 280,
        //color: Colors.yellow,
        margin: EdgeInsets.only(bottom: 40),
        child: ListView.builder(
          itemCount: doctorDetail.length,
          itemBuilder: (BuildContext context, int index) {
            return Row(
              children: [
                Align(
                  alignment: Alignment.bottomCenter,
                  child: DoctorCard(
                    doctorDetail[index].name,
                    doctorDetail[index].age,
                    doctorDetail[index].speciality,
                    doctorDetail[index].rating,
                    doctorDetail[index].clinic,
                  ),
                ),
                SizedBox(width: 18),
              ],
            );
          },
          scrollDirection: Axis.horizontal,
        ),
      ),
    );
  }
}
